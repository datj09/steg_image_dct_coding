import cv2
import numpy as np
import itertools
from math import log10, sqrt
import argparse

quant = np.array([[16,11,10,16,24,40,51,61],
                  [12,12,14,19,26,58,60,55],
                  [14,13,16,24,40,57,69,56],
                  [14,17,22,29,51,87,80,62],
                  [18,22,37,56,68,109,103,77],
                  [24,35,55,64,81,104,113,92],
                  [49,64,78,87,103,121,120,101],
                  [72,92,95,98,112,100,103,99]])

class DCT:    
    def __init__(self):
        self.message = None
        self.bitMess = None
        self.oriCol = 0
        self.oriRow = 0
        self.numBits = 0

    def encode_image(self, img, secret_msg):
        self.message = str(len(secret_msg)) + '*' + secret_msg
        self.bitMess = self.toBits()
        row, col = img.shape[:2]
        self.oriRow, self.oriCol = row, col
        if ((col/8) * (row/8) < len(secret_msg)):
            raise ValueError("Error: Message too large to encode in image")
        if row % 8 != 0 or col % 8 != 0:
            img = self.addPadd(img, row, col)

        row, col = img.shape[:2]
        bImg, gImg, rImg = cv2.split(img)
        bImg = np.float32(bImg)
        imgBlocks = [np.round(bImg[j:j+8, i:i+8] - 128) for (j, i) in itertools.product(range(0, row, 8), range(0, col, 8))]
        dctBlocks = [np.round(cv2.dct(img_Block)) for img_Block in imgBlocks]
        quantizedDCT = [np.round(dct_Block / quant) for dct_Block in dctBlocks]
        messIndex = 0
        letterIndex = 0
        for quantizedBlock in quantizedDCT:
            DC = quantizedBlock[0][0]
            DC = np.uint8(DC)
            DC = np.unpackbits(DC)
            DC[7] = self.bitMess[messIndex][letterIndex]
            DC = np.packbits(DC)
            DC = np.float32(DC).item()
            DC = DC - 255
            quantizedBlock[0][0] = DC
            letterIndex += 1
            if letterIndex == 8:
                letterIndex = 0
                messIndex += 1
            if messIndex == len(self.message):
                break
        sImgBlocks = [quantizedBlock * quant + 128 for quantizedBlock in quantizedDCT]
        sImg = []
        for chunkRowBlocks in self.chunks(sImgBlocks, col/8):
            for rowBlockNum in range(8):
                for block in chunkRowBlocks:
                    sImg.extend(block[rowBlockNum])
        sImg = np.array(sImg).reshape(row, col)
        sImg = np.uint8(sImg)
        sImg = cv2.merge((sImg, gImg, rImg))
        return sImg

    def decode_image(self, img):
        row, col = img.shape[:2]
        messSize = None
        messageBits = []
        buff = 0
        bImg, gImg, rImg = cv2.split(img)
        bImg = np.float32(bImg)
        imgBlocks = [bImg[j:j+8, i:i+8] - 128 for (j, i) in itertools.product(range(0, row, 8), range(0, col, 8))]
        quantizedDCT = [img_Block / quant for img_Block in imgBlocks]
        i = 0
        for quantizedBlock in quantizedDCT:
            DC = quantizedBlock[0][0]
            DC = np.uint8(DC)
            DC = np.unpackbits(DC)
            if DC[7] == 1:
                buff += (0 & 1) << (7 - i)
            elif DC[7] == 0:
                buff += (1 & 1) << (7 - i)
            i += 1
            if i == 8:
                messageBits.append(chr(buff))
                buff = 0
                i = 0
                if messageBits and messageBits[-1] == '*' and messSize is None:
                    try:
                        messSize = int(''.join(messageBits[:-1]))
                    except:
                        pass
            if messSize is not None and len(messageBits) - len(str(messSize)) - 1 == messSize:
                return ''.join(messageBits)[len(str(messSize)) + 1:]
        return ''

    def chunks(self, l, n):
        m = int(n)
        for i in range(0, len(l), m):
            yield l[i:i + m]

    def addPadd(self, img, row, col):
        img = cv2.resize(img, (col + (8 - col % 8), row + (8 - row % 8)))
        return img

    def toBits(self):
        bits = []
        for char in self.message:
            binval = bin(ord(char))[2:].rjust(8, '0')
            bits.append(binval)
        self.numBits = bin(len(bits))[2:].rjust(8, '0')
        return bits

class Compare:
    def psnr(self, img1, img2):
        mse = np.sum((img1.astype('float') - img2.astype('float')) ** 2)
        mse /= float(img1.shape[0] * img1.shape[1])
        if mse == 0:
            return 100
        PIXEL_MAX = 255.0
        return 20 * log10(PIXEL_MAX / sqrt(mse))

def analyze_dct_frequency(img_path):
    img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("Error: Image not found.")

    bImg, _, _ = cv2.split(img)
    bImg = np.float32(bImg)

    imgBlocks = [bImg[j:j+8, i:i+8] - 128 for (j, i) in itertools.product(range(0, img.shape[0], 8), range(0, img.shape[1], 8))]
    
    dctBlocks = [np.round(cv2.dct(img_Block)) for img_Block in imgBlocks]

    high_freq_coeffs = []
    for dctBlock in dctBlocks:
        high_freq = dctBlock[4:, 4:].flatten()
        high_freq_coeffs.extend(high_freq)

    if len(high_freq_coeffs) > 0:
        std_dev = np.std(high_freq_coeffs)
    else:
        return False

    threshold = 10.0
    return std_dev > threshold

def compare_dct_coefficients(img1, img2):
    if img1 is None or img2 is None:
        raise ValueError("Error: One or both images are invalid.")
    bImg1, _, _ = cv2.split(img1)
    bImg2, _, _ = cv2.split(img2)
    bImg1 = np.float32(bImg1)
    bImg2 = np.float32(bImg2)
    blocks1 = [bImg1[j:j+8, i:i+8] - 128 for (j, i) in itertools.product(range(0, img1.shape[0], 8), range(0, img1.shape[1], 8))]
    blocks2 = [bImg2[j:j+8, i:i+8] - 128 for (j, i) in itertools.product(range(0, img2.shape[0], 8), range(0, img2.shape[1], 8))]
    dctBlocks1 = [np.round(cv2.dct(img_Block)) for img_Block in blocks1]
    dctBlocks2 = [np.round(cv2.dct(img_Block)) for img_Block in blocks2]
    diff = 0
    for block1, block2 in zip(dctBlocks1, dctBlocks2):
        diff += np.mean(np.abs(block1 - block2))
    return diff / len(dctBlocks1)

def main():
    parser = argparse.ArgumentParser(description="DCT Steganography Lab")
    parser.add_argument("task", choices=["encode", "decode", "psnr", "analyze", "compare_dct"], help="Task to perform")
    parser.add_argument("--image", default="lenna.png", help="Input image file")
    parser.add_argument("--msg", default="Message", help="Secret message to encode")
    args = parser.parse_args()

    dct = DCT()
    compare = Compare()

    if args.task == "encode":
        img = cv2.imread(args.image, cv2.IMREAD_UNCHANGED)
        if img is None:
            print("Error: Could not load image.")
            return
        encoded_img = dct.encode_image(img, args.msg)
        cv2.imwrite("dct_stego_image.png", encoded_img, [cv2.IMWRITE_PNG_COMPRESSION, 0])
        with open("encode_result.txt", "w", encoding="utf-8") as f:
            f.write("Encoded image success")
        print("Encoded image saved as dct_stego_image.png")

    elif args.task == "decode":
        img = cv2.imread("dct_stego_image.png", cv2.IMREAD_UNCHANGED)
        if img is None:
            print("Error: dct_stego_image.png not found.")
            return
        hidden_text = dct.decode_image(img)
        with open("dct_extracted.txt", "w", encoding="utf-8") as f:
            f.write(hidden_text)
        print("Extracted message saved as dct_extracted.txt")

    elif args.task == "psnr":
        original = cv2.imread(args.image, cv2.IMREAD_UNCHANGED)
        encoded = cv2.imread("dct_stego_image.png", cv2.IMREAD_UNCHANGED)
        if original is None or encoded is None:
            print("Error: One or both images not found.")
            return
        psnr_value = compare.psnr(original, encoded)
        with open("dct_psnr.txt", "w", encoding="utf-8") as f:
            f.write(str(psnr_value))
        with open("psnr_result.txt", "w", encoding="utf-8") as f:
            f.write("success")
        print(f"PSNR value {psnr_value} saved in dct_psnr.txt")

    elif args.task == "analyze":
        stego_detected = analyze_dct_frequency(args.image)
        with open("analysis.txt", "w", encoding="utf-8") as f:
            f.write("StegoDetected" if stego_detected else "NoStegoDetected")
        print("Analysis result saved as analysis.txt")

    elif args.task == "compare_dct":
        img1 = cv2.imread(args.image, cv2.IMREAD_UNCHANGED)
        img2 = cv2.imread("dct_stego_image.png", cv2.IMREAD_UNCHANGED)
        if img1 is None or img2 is None:
            print("Error: One or both images not found.")
            return
        dct_diff = compare_dct_coefficients(img1, img2)
        with open("dct_diff.txt", "w", encoding="utf-8") as f:
            f.write(str(dct_diff))
        with open("dct_diff_result.txt", "w", encoding="utf-8") as f:
            f.write("success")
        print(f"DCT difference {dct_diff} saved in dct_diff.txt")

if __name__ == "__main__":
    main()